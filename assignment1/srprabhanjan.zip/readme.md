Details about this assignment can be found [on the course webpage](https://cvl-umass.github.io/compsci682-fall-2023/assignments/assignments2023/assignment1/), under Assignment #1 of Fall 2023.
